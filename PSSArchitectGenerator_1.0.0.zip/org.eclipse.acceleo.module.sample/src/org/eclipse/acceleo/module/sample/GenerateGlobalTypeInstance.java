package org.eclipse.acceleo.module.sample;

public class GenerateGlobalTypeInstance {

	public <GlobalTypeIntance> GlobalTypeIntance create_comp_globalTypeInstance() {
		
		return null;
		
	}
}
